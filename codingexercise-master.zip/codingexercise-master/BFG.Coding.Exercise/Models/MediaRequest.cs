﻿namespace BFG.Coding.Exercise.Models
{
	public class MediaRequest
	{
		public string collection { get; set; }
		public Media media { get; set; }
	}
}