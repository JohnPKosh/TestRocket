﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BFG.Coding.Exercise.Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
