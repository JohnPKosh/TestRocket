# Coding Exercise

The exercise will be the creation of a single page web app that displays a list of books and movies.  The user should be able to add either a new book or a new movie and have the display updated.  This should be done through ajax.

The data will be stored in a file named data.json, which should be read to populate the form.

The user interface can be whatever design you wish.

The use of a dependency injection framework is preferable.

Feel free to use any JavaScript libraries, or NuGet packages you wish to complete the exercise.